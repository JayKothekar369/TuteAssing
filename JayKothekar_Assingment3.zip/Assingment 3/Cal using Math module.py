import math

# Agenda
# calculate Sq root
# Logarithm calculation
# Sine calculation

#**square root of number
print("Square Root Calculation")
sq=int(input("Enter the number:- "))
sq_root=math.sqrt(sq)
print(f"Square root of a number is {sq_root}")
print("-----------------------------------------------------------------")


#**log calculation
print("Logarithm Calculation")
lg=float(input("Enter the value (in degree):- "))
rad_val=math.radians(lg)
base=input("Enter the base value:- ")
if base=="":
 log_cl=math.log(rad_val)
 print(f"Logarithm value is {log_cl}")
else:
 log_cl=math.log(rad_val,base)
 print(f"Logarithm value is {log_cl}")

print("-----------------------------------------------------------------")


#**Sine calculation
print("Sine Calculation")
num=float(input("Enter value (in degree):- "))
rad_val2=math.radians(num)
sine_cal=math.sin(rad_val2)

print(f"Sine value is {sine_cal}")

print("-----------------------------------------------------------------")