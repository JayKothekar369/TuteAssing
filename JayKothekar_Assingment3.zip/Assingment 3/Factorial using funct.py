# factorial using functiona


def Factorial():
    fact_num=int(input("Enter the number:- "))
    val=1
    for i in range(1,fact_num+1):
        val*=i
    print(f"Factorial of a number is {val}")


Factorial()